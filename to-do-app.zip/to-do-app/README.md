# To do app Ruben Stoop

Simple to do app

To Start:
1. Clone project
2. Run: npm install
3. Run: npm run dev
